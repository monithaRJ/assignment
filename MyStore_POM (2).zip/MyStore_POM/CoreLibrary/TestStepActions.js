
function actionClass() {
    let EC = protractor.ExpectedConditions;
    objectLocatornameFinder = function (locatorObject) {
        let locatorName1 = Object.keys(locatorObject)[0];
        return locatorName1;
    }
    objectLocatorFinder = function (locatorObject) {
        let locatorName1 = Object.keys(locatorObject)[0];
        let locator1 = locatorObject[locatorName1];
        return locator1;
    }
    this.assertToDisplay = function (locatorObject) {
        let locatorName = objectLocatornameFinder(locatorObject);
        let locator = objectLocatorFinder(locatorObject);
        expect(locator.isDisplayed()).toBe(true);
    }
    this.inputText = function (locatorObject, value) {
        let locatorName = objectLocatornameFinder(locatorObject);
        let locator = objectLocatorFinder(locatorObject);
        locator.sendKeys(value);
        console.log("text has been added on -" + locatorName);
    }
    this.getValue = function (locatorObject) {
        let locatorName = objectLocatornameFinder(locatorObject);
        let locator = objectLocatorFinder(locatorObject);
        locator.getText().then((text) => {
            if (text) {
                console.log("Text displayed for " + locatorName + " is :" + text);
                return text;
            } else {
                console.log("Text cannot be displayed on :" + locatorName)
            }
        });
    }
    this.clickOn = function (locatorObject) {
        let locatorName = objectLocatornameFinder(locatorObject);
        let locator = objectLocatorFinder(locatorObject);
        locator.click();
        console.log("clicked on :" + locatorName);
    }
    this.browserElementToBeVisible = function (locatorObject,value) {
        let locator = objectLocatorFinder(locatorObject);
        browser.wait(EC.visibilityOf(locator), value);
    }
    this.browserToWait = function (value) {
        browser.sleep(value);
    }
}
module.exports = new actionClass();