require('../../../Configuration/globalAccess.js');

describe('Create User', function () {
    it('Open Application', function () {
        browser.waitForAngularEnabled(false);
        browser.get(browser.params.appURL);
    });
    it('Validating display of Links in home Page', function () {
        homePage.homePageDisplayValidation();
       homePage.selectSigIn();
    });
    it('Authentication Page displays and create a user and signout', function () {
        authenticationPage.creatAccount();
        homePage.selectSignOut();
    });

});