require('../../../Configuration/globalAccess.js');

describe('SignIN to the application', function () {
    it('Open Application', function () {
        browser.waitForAngularEnabled(false);
        browser.get(browser.params.appURL);
    });
    it('select Sigin home Page', function () {
         homePage.selectSigIn();
    });
    it('Authentication Page displays and sigin as existing user', function () {
        authenticationPage.signIn();
    });
    it('In home page click on order history and avigate to home page', function(){
        homePage.orderHistorySelection();
        orderHistoryPage.backToHome();
    });
    
});