require('../../Configuration/globalAccess.js');

function OrderHistory_Page(){
    let homeButton = element(by.xpath("//span[contains(text(),' Home')]"));

    this.backToHome = function(){
        activity.clickOn({homeButton});
    }
}
module.exports = new OrderHistory_Page();



