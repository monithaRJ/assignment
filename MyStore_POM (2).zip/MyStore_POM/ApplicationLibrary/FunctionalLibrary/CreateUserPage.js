require('../../Configuration/globalAccess.js');
function createUser_Page() {
    let createAccountTab = element(by.xpath("//*[text()='Your personal information']"));
    let firstName= element(by.css("#customer_firstname"));
    let lastName= element(by.css("#customer_lastname"));
    let password= element(by.css("#passwd"));
        let address_firstName= element(by.css("#firstname"));
    let address_lastName= element(by.css("#lastname"));
    let address= element(by.css("#address1"));
    let city= element(by.css("#city"));
    let state= element(by.css("#id_state"));
    let zip= element(by.css("#postcode"));
    let mobilePhone= element(by.css("#phone_mobile"));
    let register= element(by.css("#submitAccount"));


    this.detailsToAddUser = function () {
        activity.browserElementToBeVisible({ createAccountTab }, testData.visibilitytimeout);
        activity.inputText({firstName},testData.createAccount.firstName);
        activity.inputText({lastName},testData.createAccount.lastName);
        activity.inputText({password},testData.createAccount.password);
        activity.inputText({address_firstName},testData.createAccount.firstName);
        activity.inputText({address_lastName},testData.createAccount.firstName);
        activity.inputText({address},testData.createAccount.address);
        activity.inputText({city},testData.createAccount.city);
        activity.inputText({state},testData.createAccount.state);
        activity.inputText({zip}, testData.createAccount.zip);
        activity.inputText({mobilePhone},testData.createAccount.phone);
        activity.clickOn({register});
    }
}
module.exports = new createUser_Page();