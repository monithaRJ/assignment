require('../../Configuration/globalAccess.js');
function authentication_Page() {
    let emailIDTextBoxToCreate = element(by.css("#email_create"));
    let creatAccountButton = element(by.css("#SubmitCreate"));
    let emailIDTextBoxToSignIn = element(by.css("#email"));
    let passwordToSignIn = element(by.css("#passwd"));
    let dangerAlert = element(by.css("#create_account_error"));
    let createAccountTab = element(by.xpath("//*[text()='Your personal information']"));
    let signIN = element(by.css("#SubmitLogin"));

    this.creatAccount = function () {
        activity.inputText({ emailIDTextBoxToCreate }, testData.newEmailID);
        activity.clickOn({ creatAccountButton });
        activity.browserToWait(testData.waitTimeout);
        dangerAlert.isDisplayed().then((value) => {
            if (value) {
                console.log("user exist");
            } else {
                createUserPage.detailsToAddUser();
            }
        })
    }
    this.signIn = function () {
        activity.inputText({ emailIDTextBoxToSignIn }, testData.newEmailID);
        activity.inputText({ passwordToSignIn }, testData.createAccount.password);
        activity.clickOn({ signIN });
    }
}
module.exports = new authentication_Page();