require('../../Configuration/globalAccess.js');
function home_Page() {
    let myStoreLogo = element(by.css("img[alt='My Store']"));
    let contactUsLink = element(by.css("a[title='Contact us']"));
    let signInLink = element(by.css(".login"));
    let signOutLink = element(by.xpath("//a[@title='Log me out']"))
    let cartLink = element(by.xpath("//a[@title='View my shopping cart']"));
    let searchInput = element(by.xpath("//input[@placeholder='Search']"));
    let homePage_OrderHistory = element(by.xpath("//span[contains(text(),'Order history and details')]"));


    this.homePageDisplayValidation = function () {
        activity.assertToDisplay({ myStoreLogo });
        activity.assertToDisplay({ contactUsLink });
        activity.assertToDisplay({ signInLink });
        activity.assertToDisplay({ cartLink });
        activity.assertToDisplay({ searchInput });
    }
    this.selectSigIn = function () {
        activity.clickOn({ signInLink });
    }
    this.orderHistorySelection = function () {
        activity.clickOn({ homePage_OrderHistory });
    }
    this.selectSignOut = function () {

        signOutLink.isPresent().then((value) => {
            if (value) {
                activity.clickOn({ signOutLink });
                console.log("user can do a sign out");
            } else {
                console.log("user creation cannot be done as user already exist so cannot signout")
            }
        });
    }

}
module.exports = new home_Page();