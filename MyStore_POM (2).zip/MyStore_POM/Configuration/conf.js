var HtmlReporter = require('protractor-beautiful-reporter');



exports.config = {
  directConnect: true, 
  capabilities: {
    'browserName': 'chrome',
    unexpectedAlertBehaviour: 'accept'
  },
  params: {
    'appURL': "http://automationpractice.com/",
    'env': "Test"
  },

  framework: 'jasmine',
  //seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['../ApplicationLibrary/e2e/Suite/*.js'],

  jasmineNodeOpts: {
    defaultTimeoutInterval: 900000
  },

  //restartBrowserBetweenTests:true,

  onPrepare: function () {
    //to maximize the screen
    browser.driver.manage().window().maximize();

    //adding default implict wait 
    browser.driver.manage().timeouts().implicitlyWait(5000);
    jasmine.getEnv().addReporter(new HtmlReporter({
      baseDirectory: 'report/screenshots'
      , preserveDirectory: false
    }).getJasmine2Reporter());
    //Allure reporting 
    let AllureReporter = require('jasmine-allure-reporter');
    jasmine.getEnv().addReporter(new AllureReporter({
      resultsDir: 'allure-results'
    }));
    jasmine.getEnv().afterEach(function (done) {
      browser.takeScreenshot().then(function (png) {
        allure.createAttachment('Screenshot', function () {
          return new Buffer(png, 'base64')
        }, 'image/png')();
        done();
      })
    });
    var allu = require('allure-commandline');
    let generation = allu(['generate', 'allure-results']);
    generation.on('exit', function (exitCode) {
      console.log('Generation is finished with code:', exitCode);
    });
    
  }
}