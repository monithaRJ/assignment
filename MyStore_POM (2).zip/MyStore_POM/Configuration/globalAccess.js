global.homePage = require('../ApplicationLibrary/FunctionalLibrary/HomePage.js');
global.activity = require('../CoreLibrary/TestStepActions.js');
global.authenticationPage = require('../ApplicationLibrary/FunctionalLibrary/AuthenticationPage.js');
global.testData = require('../ApplicationLibrary/e2e/TestData.json');
global.createUserPage = require('../ApplicationLibrary/FunctionalLibrary/CreateUserPage.js')
global.orderHistoryPage = require('../ApplicationLibrary/FunctionalLibrary/OrderHistoryPage.js')